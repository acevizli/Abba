import 'package:flutter/material.dart';
import 'package:flutter_appp/welcome.dart';
import 'package:flutter_appp/constants.dart';
import 'package:flutter_appp/textStyle.dart';
import 'package:flutter_appp/walkThrough.dart';
import 'package:flutter_appp/home.dart';



void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Auth',
      theme: ThemeData(
        primaryColor: kPrimaryColor,
        scaffoldBackgroundColor: Colors.white,
      ),
      routes:
      {
        '/': (context) => Splash(),

      },
      //initialRoute:
      //home: WelcomeScreen(),
    );
  }
}