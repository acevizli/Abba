enum BottomNavbarItem {
  Main,
  Search,
  Create,
  DM,
  Profile,
  Notifications,
}