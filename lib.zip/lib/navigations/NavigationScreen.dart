import 'package:flutter/material.dart';
import 'package:flutter_appp/Profile/ProfilePage.dart';
import 'package:flutter_appp/Search/search_username.dart';
import 'package:flutter_appp/feed_screen.dart';
import 'package:flutter_appp/login_screen.dart';
import 'package:flutter_appp/notifications/notification_screen.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Classes.dart';
import '../textStyle.dart';
import 'BottomNavbar.dart';
import 'BottomNavbarItem.dart';
class NavigationScreen extends StatefulWidget {
  @override
  _NavigationScreenState createState() => _NavigationScreenState();
}
class _NavigationScreenState extends State<NavigationScreen> {
  int index;
  final Map<BottomNavbarItem,IconData> items = const {
    BottomNavbarItem.Main: Icons.home,
    BottomNavbarItem.Create: Icons.add,
    BottomNavbarItem.Profile: Icons.person,
    BottomNavbarItem.Search: Icons.search,
    BottomNavbarItem.DM: Icons.mail,
    BottomNavbarItem.Notifications: Icons.notifications,
  };
  final List<Widget> screens = [ //add your screens here
    FeedScreen(),
    null,
    ViewProfileScreen(user: users[0],),
    Search(),
    null,
    NotificationScreen(),
  ];
  @override
  void initState() {
    super.initState();
    index = 0;
  }
  @override
  Widget build(BuildContext context) { //TODO dont return to login screen something similar walkthrough
    return Scaffold(
      body: screens[index],
      bottomNavigationBar: BottomNavBar(
        onTap: (_index) => setState(() => index = _index),
        items: items,
        selected: BottomNavbarItem.values[index],
      ),
    );
  }
}
